import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { MatButtonModule, MatGridListModule, MatCardModule,
MatInputModule, MatCheckboxModule, MatIconModule, MatSidenavModule,
MatMenuModule, MatToolbarModule, MatExpansionModule , MatTabsModule } from '@angular/material';
import { MainComponent } from './layout/main/main.component';

import {RouterModule, Routes} from '@angular/router';
import { LoginComponent } from './layout/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { Dashboard2Component } from './pages/dashboard2/dashboard2.component';
import { TopComponent } from './layout/top/top.component';
import { InterviewComponent } from './pages/interview/interview.component';


const routes: Routes = [
  {path: '', redirectTo: 'login', pathMatch: 'full'},
  {path: 'login', component: LoginComponent},
  {path: 'main', component: MainComponent, children : [
    { path: 'main', component: MainComponent, outlet: 'main'},
    { path: 'dashboard', component: DashboardComponent },
    { path: 'dashboard2', component: Dashboard2Component }


  ]},
  {path: 'interview', component: InterviewComponent},
];

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    LoginComponent,
    DashboardComponent,
    Dashboard2Component,
    TopComponent,
    InterviewComponent
  ],
  imports: [
    BrowserModule, BrowserAnimationsModule, MatIconModule, MatGridListModule, MatMenuModule,
    MatCardModule, BrowserAnimationsModule, MatSidenavModule, MatExpansionModule,
    MatButtonModule, MatCheckboxModule, MatInputModule, MatToolbarModule, MatTabsModule, RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
